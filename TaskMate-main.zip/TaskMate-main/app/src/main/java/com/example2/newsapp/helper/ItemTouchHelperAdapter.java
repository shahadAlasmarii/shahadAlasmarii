package com.example2.newsapp.helper;

public interface ItemTouchHelperAdapter {


    void onItemMove(int fromPosition, int toPosition);



    void onItemDismiss(int position);
}
