package com.example2.newsapp.helper;


public interface ItemTouchHelperViewHolder {


    void onItemSelected();



    void onItemClear();
}
